#include "stdafx.h"
#include "wzhlib.h"
#include "math.h"
#include "matlib.h"

#include <fstream>
using namespace std;

/********************************************************************************

						��ʽת��

********************************************************************************/
void Trans2
	(IplImage* pimage,byte* pImageData, int nWidth,int nHeight)
{
	memcpy(pimage->imageData,pImageData,nWidth*nHeight);
	pimage->width = nWidth;
	pimage->height = nHeight;
	pimage->imageSize = nWidth*nHeight;
	pimage->nChannels = 1;
}

void Trans2IplImage(IplImage* pimage,double* pImageData, int nWidth,int nHeight)
{
	int nSize = nWidth * nHeight;
	wzhAbs(pImageData,nSize);
	wzhNormorlize(pImageData,nSize,255.0f);

	byte* pTemp = new byte[nWidth*nHeight];
	Float2Byte(pTemp,pImageData,nWidth*nHeight);
	memcpy(pimage->imageData,pTemp,nWidth*nHeight);
	pimage->width = nWidth;
	pimage->height = nHeight;
	pimage->imageSize = nWidth*nHeight;
	pimage->nChannels = 1;
	delete pTemp;
}

void	GetIplImageData(double* pImageData,IplImage* pimage)
{
	int nWidth	= pimage->width;
	int nHeight = pimage->height;
	int nLineWidth = pimage->widthStep;
	for(int i = 0; i < nHeight; i++)
		for(int j =0; j < nWidth; j++)
		{
			int k1 = i*nLineWidth + j;
			byte byTemp = (byte)pimage->imageData[k1];
			int k2 = i*nWidth + j;
			pImageData[k2] = (double)byTemp;
		}
}


Image	CVImage2WanImage(IplImage* pGrayimage)
{
	int nWidth = pGrayimage->width;
	int nHeight = pGrayimage->height;
	Image image(nWidth,nHeight);
	for (int r = 0; r < nHeight; r++)
		for (int c = 0; c < nWidth; c++)
		{
			int pos = r*nWidth+c;
			image(c,r) = ((double) pGrayimage->imageData[pos]) / 255.0;
		}
		return image;
}

Image	CreatWanImage(double* pGrayimage,int nWidth,int nHeight)
{
	Image image(nWidth,nHeight);
	for (int r = 0; r < nHeight; r++)
		for (int c = 0; c < nWidth; c++)
		{
			int pos = r*nWidth+c;
			image(c, r) = ((double) pGrayimage[pos]) / 255.0;
		}
	return image;
}

/********************************************************************************

						CV ��ʾ���
	
********************************************************************************/
/*void wzhShowData(double* pData,int nWidth,int nHeight,char* name)
{
	double* pTemp = new double[nWidth*nHeight];
	memcpy(pTemp,pData,sizeof(double)*nWidth*nHeight);
	IplImage* pImageTemp = cvCreateImage(cvSize(nWidth,nHeight),IPL_DEPTH_8U,1);
	Trans2IplImage(pImageTemp,pData,nWidth,nHeight);
	cvNamedWindow(name,2);
	cvShowImage(name,pImageTemp);
	cvWaitKey(0);
	cvDestroyWindow(name);
	cvReleaseImage(&pImageTemp);
	wzhFreePointer(pTemp);
}

void wzhShowData(byte* pData,int nWidth,int nHeight,char* name)
{
	byte* pTemp = new byte[nWidth*nHeight];
	memcpy(pTemp,pData,sizeof(byte)*nWidth*nHeight);
	IplImage* pImageTemp = cvCreateImage(cvSize(nWidth,nHeight),IPL_DEPTH_8U,1);
	Trans2IplImage(pImageTemp,pData,nWidth,nHeight);
	cvNamedWindow(name,2);
	cvShowImage(name,pImageTemp);
	cvWaitKey(0);
	cvDestroyWindow(name);
	cvReleaseImage(&pImageTemp);
	wzhFreePointer(pTemp);
}*/

/********************************************************************************
��������
MarkCornerImage
������
�ú�����ʾ�ǵ�ͼ��
�����
********************************************************************************/
void	wzhShowPointsOfImage(IplImage* pImage,int* pPoints,int nCount)
{
	CvScalar color = cvScalar(0, 0, 255);
	for(int i = 0; i < nCount; i++)
	{
		int rr = pPoints[2*i];
		int cc = pPoints[2*i+1];

		CvPoint pt1, pt2;
		pt1.x = cc-2; 
		pt1.y = rr-2;
		pt2.x = cc+2; 
		pt2.y = rr+2;
		cvRectangle(pImage, pt1, pt2, color);
	}

	char* name = "KeyPoints Detected";
	cvNamedWindow(name,2);
	cvShowImage(name,pImage);
	cvWaitKey(0);
	cvDestroyWindow(name);
}

BOOL wzhLoadImage(double*& pImageData, int& nWidth,int& nHeight,char* filename)
{
	//����ͼ�� 
	IplImage*	cvGrayimg	= cvLoadImage(filename,0);
	if(cvGrayimg == NULL)
	{
		return FALSE;
	}
	nWidth = cvGrayimg->width;
	nHeight	= cvGrayimg->height;
	pImageData	= new double[nWidth*nHeight];
	GetIplImageData(pImageData,cvGrayimg);
	cvReleaseImage(&cvGrayimg);

	return TRUE;
}

/********************************************************************************

							�ļ����

********************************************************************************/
bool wzhOut(char* filename,double* pData,int nWidth, int nHeight)
{
	ofstream outfile;
	outfile.open(filename);

	//Ѱ�ұ���
	for(int i = 0; i < nHeight; i++)
	{
		for(int j = 0; j < nWidth; j++)
		{
			int  k = i * nWidth + j;
			outfile << pData[k] << "\t";
		}
		outfile << endl;
	}
	outfile.close();

	return true;
}

bool wzhOut(char* filename,float* pData,int nWidth, int nHeight)
{
	ofstream outfile;
	outfile.open(filename);

	//Ѱ�ұ���
	for(int i = 0; i < nHeight; i++)
	{
		for(int j = 0; j < nWidth; j++)
		{
			int  k = i * nWidth + j;
			outfile << pData[k] << " ";
		}
		outfile << endl;
	}
	outfile.close();

	return true;
}

void GetExeDir(char dirName[])
{
// 	TCHAR szFull[_MAX_PATH];
// 	TCHAR szDrive[_MAX_DRIVE];
// 	TCHAR szDir[_MAX_DIR];
// 	::GetModuleFileName(NULL, szFull, sizeof(szFull)/sizeof(TCHAR));
// 	_tsplitpath(szFull, szDrive, szDir, NULL, NULL);
// 	_tcscpy(szFull, szDrive);
// 	_tcscat(szFull, szDir);
// 	_tcscpy(dirName, szFull);
}

bool	LoadCornerTxt(double*& pfCorners,int& iCornersCount,char* cornerPath)
{

	FILE * fp1;
	fp1 = fopen(cornerPath,"r");
	if (!fp1) 
	{
		return false;
	}

	//��ȡ��һ�еĽǵ���
	fscanf(fp1,"%i",&iCornersCount);

	wzhFreePointer(pfCorners);
	pfCorners = new double[iCornersCount*2];

	//��ȡ�ǵ���Ϣ
	for (int i = 0; i < iCornersCount; i++) 
	{
		float rr;
		float cc;
		fscanf(fp1,"%f",&rr);
		fscanf(fp1,"%f",&cc);
		pfCorners[2*i]		= (double)rr;
		pfCorners[2*i+1]	= (double)cc;
	}

	fclose(fp1);
	return true;
}

bool	LoadMatchCornerTxt(double*& pfCorners1,double*& pfCorners2,int& iCornersCount,char* cornerPath)
{
	FILE * fp1;
	fp1 = fopen(cornerPath,"r");
	if (!fp1) 
	{
		return false;
	}

	//��ȡ��һ�еĽǵ���
	fscanf(fp1,"%i",&iCornersCount);
	pfCorners1 = new double[iCornersCount*3];
	pfCorners2 = new double[iCornersCount*3];

	//��ȡ�ǵ���Ϣ
	for (int i = 0; i < iCornersCount; i++) 
	{
		double rr;
		double cc;
		fscanf(fp1,"%f",&rr);
		fscanf(fp1,"%f",&cc);
		pfCorners1[3*i]		= rr;
		pfCorners1[3*i+1]	= cc;
		pfCorners1[3*i+2]	= 1.0f;
		fscanf(fp1,"%f",&rr);
		fscanf(fp1,"%f",&cc);
		pfCorners2[3*i]		= rr;
		pfCorners2[3*i+1]		= cc;
		pfCorners2[3*i+2]	= 1.0f;
	}

	fclose(fp1);
	return true;
}

bool	LoadLineTxt_endpts(double*& pLinePts,int& nLineCount,int nCountForEachLine[],char* txtFilename)
{
	//���ļ�
	FILE * fp1;
	fp1 = fopen(txtFilename,"r");
	if (!fp1) 
	{
		return false;
	}
	//����ֱ������
	fscanf(fp1,"%i",&nLineCount);
	double* pEndpts = new double[nLineCount*4];
	int totalPixel= 0;
	double sx, sy, ex, ey;
	for (int i = 0; i < nLineCount; i++)
	{
		fscanf(fp1,"%lf",&sx);
		fscanf(fp1,"%lf",&sy);
		fscanf(fp1,"%lf",&ex);
		fscanf(fp1,"%lf",&ey);		
		int npixel = (int)max(abs(ey-sy), abs(ex-sx));
		nCountForEachLine[i] = npixel;
		totalPixel += npixel; 		
		pEndpts[4*i] = sx;
		pEndpts[4*i+1] = sy;
		pEndpts[4*i+2] = ex;
		pEndpts[4*i+3] = ey;
	}	

	pLinePts = new double[totalPixel*2];
	int ncount = 0;
	for (int i = 0; i < nLineCount; i++)
	{		
		sx = pEndpts[4*i];
		sy = pEndpts[4*i+1];
		ex = pEndpts[4*i+2];
		ey = pEndpts[4*i+3];
		int npixel = nCountForEachLine[i];
		double dx = (ex-sx) / npixel;
		double dy = (ey-sy) / npixel;
		for( int j = 0; j < npixel; j++)
		{
			pLinePts[2*ncount] = max((int)sy + j*dy, 0.);
			pLinePts[2*ncount+1] = max((int)sx + j*dx,0.);
			ncount++;
		}		
	}	

	delete[] pEndpts;
	pEndpts = NULL;

	fclose(fp1);
	return true;
}

bool	LoadLineTxt(double*& pLinePts,int& nLineCount,int nCountForEachLine[],char* txtFilename)
{
	//���ļ�
	FILE * fp1;
	fp1 = fopen(txtFilename,"r");
	if (!fp1) 
	{
		return false;
	}

	//����ֱ������
	fscanf(fp1,"%i",&nLineCount);
	
	//��ȡ��ֱ���ϵ�ĸ���
	int nTotol = 0;
	for(int i = 0; i < nLineCount; i++)
	{
		int nTemp = 0;
		fscanf(fp1,"%i",&nTemp);
		nCountForEachLine[i] = nTemp;
		nTotol = nTotol + nTemp;
	}

	//��ȡ������
	wzhFreePointer(pLinePts);
	pLinePts = new double[nTotol*2];
	int nCount = 0;
	while(!feof(fp1))
	{
		float rr;
		float cc;
		fscanf(fp1,"%f",&rr);
		fscanf(fp1,"%f",&cc);
		pLinePts[2*nCount]   = (double)(rr-1);
		pLinePts[2*nCount+1] = (double)(cc-1);
		nCount ++;
		if(nCount > nTotol-1)
		{
			break;
		}
	}


	fclose(fp1);
	return true;
}

bool	LoadFlagTxt(int& nNumber1,int& nNumber2,char* txtFileFlag)
{
	//���ļ�
	FILE * fp1;
	fp1 = fopen(txtFileFlag,"r");
	if (!fp1) 
	{
		return false;
	}

	//����ֱ������
	fscanf(fp1,"%i",&nNumber1);
	fscanf(fp1,"%i",&nNumber2);

	fclose(fp1);
	return true;
}

/********************************************************************************

							�������

********************************************************************************/
void	RGB2gray(byte* pDataGray,const byte* pDataRGB,int nWidth,int nHeight)
{  
	for(int i = 0;i < nHeight; i++)
		for(int j = 0; j < nWidth; j++)
		{
			int  k = i*nWidth + j;
			pDataGray[k] = (byte)(pDataRGB[3*k+2]*0.2989f) + (byte)(pDataRGB[3*k+1]*0.5870f) + (byte)(pDataRGB[3*k]*0.1140f);
		} 
}

void	Float2Byte(byte* pByteData,double* pFloatData,int nSize)
{
	for(int i = 0; i < nSize; i++)
	{
		double tt = (char)pFloatData[i];
		byte by = (char)tt;
		pByteData[i] = (char)pFloatData[i];
	}
}

double	wzhMax(const double* pData, int nSize)
{
	double fMax = pData[0];
	for(int  i = 0; i < nSize; i++)
	{
		if(pData[i] > fMax)
			fMax = pData[i];
	}
	return fMax;
}

void wzhMax(double& maxV,int& maxPos,const double* pData, int nSize)
{
	maxV = pData[0];
	for(int  i = 0; i < nSize; i++)
	{
		if(pData[i] > maxV)
		{
			maxV = pData[i];
			maxPos = i;
		}
	}
}
double	wzhMin(const double* pData, int nSize)
{
	double fMax = 100000;
	for(int  i = 0; i < nSize; i++)
	{
		if(pData[i] < fMax)
			fMax = pData[i];
	}
	return fMax;
}

double	wzhMean(const double* pData, int nSize)
{
	double fSumV = wzhSum(pData,nSize);
	return fSumV/(double)nSize;
}

double	wzhSum(const double* pData, int nSize)
{
	double fReult = 0;
	for(int i = 1; i < nSize; i++)
	{
		fReult = fReult + pData[i];
	}
	return fReult;
}

void	wzhAbs(double* pData,int nSize)
{
	for(int i = 0; i < nSize; i ++)
	{
		pData[i] = abs(pData[i]);
	}
}
void	wzhSqare(double* pData,int nSize)
{
	for(int i = 0; i < nSize; i ++)
	{
		pData[i] = pData[i] * pData[i];
	}
}

void	wzhNormorlize(double* pData,int nSize,double fV)
{
	double maxV = wzhMax(pData,nSize);
	for(int i = 0; i < nSize; i++)
	{
		pData[i] = pData[i]*fV/maxV;
	}
}

void	wzhNormorlizeNorm(double* pData,int nSize)
{
	double fNorm = 0.0f;
	for(int i = 0; i < nSize; i++)
	{
		double fTemp  = pData[i];
		fNorm = fNorm + fTemp*fTemp;
	}
	fNorm = (double)sqrt((double)fNorm);
	if(fNorm < EPS_CONST)
	{
		return;
	}
	for(int i = 0; i < nSize; i++)
	{
		pData[i] = pData[i]/fNorm;
	}
}

void	wzhMulMatrix(double* pResult,const double* pMatrix1,const double* pMatrix2,int nDataLength)
{
	for(int i = 1; i < nDataLength; i++)
	{
		pResult[i] = pMatrix1[i]*pMatrix2[i];
	}
}

void	wzhMulMatrix(byte* pResult,const byte* pMatrix1,const byte* pMatrix2,int nDataLength)
{
	for(int i = 1; i < nDataLength; i++)
	{
		pResult[i] = pMatrix1[i]*pMatrix2[i];
	}
}

void	wzhFindMaximum(byte* pResult,int& nCount,double* pData,int nWidth,int nHeight,int nR)
{
	nCount = 0;
	memset(pResult,0,sizeof(byte)*nWidth*nHeight);
	for(int i = nR; i < nHeight-nR-1; i++)
		for(int j = nR; j < nWidth-nR-1; j++)
		{
			int k = i*nWidth+j;
			bool flag = true;
			for(int k1 = 0; k1 < 2*nR+1; k1++)
			{
				for(int k2 = 0; k2 < 2*nR+1; k2++)
				{
					int ii = i - nR + k1;
					int jj = j - nR + k2;
					int kk = ii*nWidth + jj;
					if(pData[k] < pData[kk])
					{
						flag = false;
						break;
					}
				}
				if(!flag)
				{
					break;
				}
			}
			if(flag)
			{
				pResult[k] = 1;
				nCount++;
			}
		}
}

void	wzhFindNonZeros(double*& pPs,int& nCount,byte* pData,int nWidth,int nHeight)
{
	double* pTemp = new double[nWidth*nHeight*2];
	nCount = 0;
	for(int i = 0; i < nHeight; i++)
		for(int j = 0; j < nWidth; j++)
		{
			int k = i*nWidth + j;
			if(pData[k] > 0)
			{
				pTemp[2*nCount] = (double)i;
				pTemp[2*nCount+1] = (double)j;
				nCount++;
			}
		}
	pPs = new double[nCount*2];
	memcpy(pPs,pTemp,sizeof(double)*nCount*2);
	wzhFreePointer(pTemp);
}

void	wzhThreshold(byte* pResult,double* pData,int nWidth,int nHeight,double fT)
{
	memset(pResult,0,sizeof(byte)*nWidth*nHeight);
	for(int i = 0; i < nHeight; i++)
		for(int j = 0; j < nWidth; j++)
		{
			int k = i * nWidth + j;
			if(pData[k] > fT)
			{
				pResult[k] = 1;
			}
		}
}

/*****************************************************************
	������ 
		�ú����������
*****************************************************************/
void	wzhConvol(double* pImageDataResult, const double* pImageData,int nWidth,int nHeight,double* pfTempalte,int nR)
{
	double* pTemp = new double[nWidth*nHeight];
	memset(pTemp,0,sizeof(double)*nWidth*nHeight);

	int nN = 2*nR + 1;
	for(int i = 0; i < nHeight; i++)
		for(int j = 0; j < nWidth; j++)
		{
			int k = i*nWidth+j;
			if(i < nR || j < nR || i >= nHeight-nR || j >= nWidth-nR)
			{
				continue;
			}
			double fAdd = 0.0f;
			for(int k1 = 0; k1 < nN; k1++)
				for(int k2 = 0; k2 < nN; k2++)
				{
					int ii = (i+k1-nR);
					int jj = (j+k2-nR);
					int kk = ii*nWidth + jj;
					int pos = k1*nN + k2;
					fAdd = fAdd + pImageData[kk]*pfTempalte[pos];
				}
			pTemp[k] = fAdd;
		}
	memcpy(pImageDataResult,pTemp,sizeof(double)*nWidth*nHeight);
	wzhFreePointer(pTemp);

}

double	wzhDot(double* pData1,double* pData2,int nDim)
{
	double fReturn = 0.0f;
	for(int i = 0; i < nDim; i++)
	{
		fReturn = pData1[i]*pData2[i];
	}
	return fReturn;
}
float	wzhDistance(float* pData1,float* pData2,int nDim)
{
	float fReturn = 0.0f;
	for(int i = 0; i < nDim; i++)
	{
		float fTemp = pData1[i]-pData2[i];
		fReturn = fReturn + fTemp*fTemp;
	}
	return (float)sqrt((double)fReturn);
}

void	wzhSet(double* pData,double fV, int nSize)
{
	for(int i = 0; i < nSize; i++)
	{
		pData[i] = fV;
	}
}

int	wzhRound(double dData)
{
	int iReturn = (int)dData;
	double error = abs(iReturn-dData);
	if(dData >= 0 && error > 0.5)
	{
		iReturn = iReturn + 1;
	}
	else if(dData < 0 && error > 0.5)
	{
		iReturn = iReturn - 1;
	}
	return iReturn;
}

int	wzhRange(int nP,int nMin,int nMax)
{
	int nReturn = nP;
	if(nP < nMin)
		nReturn = nMin;
	if(nP > nMax)
		nReturn = nMax;
	return nReturn;
}

/****************************************************************************

		
							�����ݶ���Ϣ


****************************************************************************/
void ConputeGaussianGrad(double* pResult,double* pOri,int nWidth,int nHeight,double fSigma,int nType)
{
	double * pTemp = new double[nWidth*nHeight];

	//���㴰�ڴ�С
	int nTemR = (int)(3*fSigma);
	if(abs(3*fSigma - nTemR) > 0.5)
	{
		nTemR++;
	}
	int nN = 2*nTemR + 1;

	//�����ڴ�
	double*	fTemD2	= new double[nN*nN];
	
	//����ģ����ݶ�ͼ��
	ComputeGaussianTepalte(fTemD2,nTemR,fSigma,nType);
	wzhConvol(pTemp, pOri,nWidth,nHeight,fTemD2,nTemR);

	//���ƽ��
	memcpy(pResult,pTemp,nWidth*nHeight*sizeof(double));

	//�ͷ��ڴ�
	if(fTemD2)
	{
		delete fTemD2;
		fTemD2 = NULL;
	}
	if(pTemp)
	{
		delete pTemp;
		pTemp = NULL;
	}

}

void	ComputeMag(double* fMag,double* pOri,int nWidth,int nHeight,double fSigma)
{
	double * pTemp = new double[nWidth*nHeight];

	//�����ڴ�
	double* pImageDx = new double[nWidth*nHeight];
	double* pImageDy = new double[nWidth*nHeight];

	//����DX DY
	ConputeGaussianGrad(pImageDx,pOri,nWidth,nHeight,fSigma,11);
	ConputeGaussianGrad(pImageDy,pOri,nWidth,nHeight,fSigma,12);

	//����ģ
	ComputeMag(pTemp,pImageDx,pImageDy,nWidth*nHeight);

	//���ƽ��
	memcpy(fMag,pTemp,nWidth*nHeight*sizeof(double));

	//�ͷ��ڴ�
	if(pImageDx != NULL)
	{
		delete pImageDx;
		pImageDx = NULL;
	}
	if(pImageDy != NULL)
	{
		delete pImageDy;
		pImageDy = NULL;
	}

	if(pTemp)
	{
		delete pTemp;
		pTemp = NULL;
	}
}

void	ComputeMag(double* fMag,const double* fGx,const double* fGy,int nSize)
{
	for(int k = 0; k < nSize; k++)
	{
		fMag[k] = sqrt(fGx[k]*fGx[k] + fGy[k]*fGy[k]);
	}
}

/*****************************************************************
������ 
	�ú��������˹ģ��
	type 0  ����0��		11����1��x		12 ���� 1��y	
		21 ����2��xx	22����2��yy		212���� 2��xy
*****************************************************************/
void	ComputeGaussianTepalte(double* pTempalte,int nR,double fSigma,int type)
{
	int nN = 2*nR + 1;
	double fSigma_2 = fSigma*fSigma;
	double fSigma_4 = fSigma_2*fSigma_2;
	double fSigma_6 = fSigma_4*fSigma_2;
	for(int i = 0; i< nN; i++)
		for(int j = 0; j< nN; j++)
		{
			double	y = i - (double)nR;
			double	x = j - (double)nR;
			double	dis_2 = x*x + y*y;
			if(dis_2 > nR*nR)
			{
				pTempalte[i*nN+j] = 0;
				continue;
			}
			double   temp = exp(-dis_2/(2*fSigma_2));

			//0��
			if(type == 0)
				pTempalte[i*nN+j] = (double)(temp / (2*PI*fSigma_2));

			//1��
			else if(type == 11)
				pTempalte[i*nN+j] = (double)(-x*temp / (2*PI*fSigma_4));
			else if(type == 12)
				pTempalte[i*nN+j] = (double)(-y*temp / (2*PI*fSigma_4));

			//2��
			else if(type == 21)
				pTempalte[i*nN+j] = (double)((x*x-fSigma_2)*temp / (2*PI*fSigma_6));
			else if(type == 22)
				pTempalte[i*nN+j] = (double)((y*y-fSigma_2)*temp / (2*PI*fSigma_6));
			else if(type == 212)
				pTempalte[i*nN+j] = (double)(x*y*temp / (2*PI*fSigma_6));
		}
}


/*****************************************************************

						���� 

*****************************************************************/
int		ComputeAngle(double fR, double fC)
{
	double xx = fC;
	double yy = fR;
	double arc = atan2((double)xx,(double)yy);
	if(arc < 0)
	{
		arc = arc + 2*PI;
	}
	int nAngle = (int)(arc*180/PI);
	return nAngle;
}

void	ComputeHarrisCurvature(double* pResult,double* pOri,int nWidth,int nHeight,double fSigma)
{
	//ģ��
	double	fTemDX[9]	=	{-1,0,1,	-1,0,1, -1,0,1};
	double	fTemDY[9]	=	{-1,-1,-1,	0,0,0,	1,1,1 };
	
	//�����ڴ�
	double* pDx = new double[nWidth*nHeight];
	double* pDy = new double[nWidth*nHeight];
	double* pDxy = new double[nWidth*nHeight];

	//�ݶ�
	wzhConvol(pDx, pOri,nWidth,nHeight,&fTemDX[0],1);
	wzhConvol(pDy, pOri,nWidth,nHeight,&fTemDY[0],1);

	//2
	wzhMulMatrix(pDxy,pDx,pDy,nWidth*nHeight);
	wzhSqare(pDx,nWidth*nHeight);
	wzhSqare(pDy,nWidth*nHeight);

	//Blur
	ConputeGaussianGrad(pDx,pDx,nWidth,nHeight,fSigma,0);
	ConputeGaussianGrad(pDy,pDy,nWidth,nHeight,fSigma,0);
	ConputeGaussianGrad(pDxy,pDxy,nWidth,nHeight,fSigma,0);

	memset(pResult,0,sizeof(double)*nWidth*nHeight); 
	double fEeps = 0.0001f;
	for(int i = 0; i < nHeight; i++)
		for(int j = 0; j < nWidth; j++)
		{
			int k = i*nWidth + j;
			double Ix2 = pDx[k];
			double Iy2 = pDy[k];
			double Ixy = pDxy[k];
			pResult[k] = abs((Ix2*Iy2 - Ixy*Ixy)/(Ix2 + Iy2 + fEeps)); 
		}

	//�ͷ��ڴ�
	if(pDx != NULL)
	{
		delete pDx;
		pDx = NULL;
	}
	if(pDy != NULL)
	{
		delete pDy;
		pDy = NULL;
	}
	if(pDxy != NULL)
	{
		delete pDxy;
		pDxy = NULL;
	}
}


void	ComputeLogEnergy(double* pResult,double* pOri,int nWidth,int nHeight,double fSigma)
{
	int nR = (int)(fSigma*3.0f);
	int nN = 2*nR + 1;

	//�ݶ�
	double* pTemXX = new double[nN*nN];
	double* pTemYY = new double[nN*nN];
	double* pTem_Log = new double[nN*nN];
	ComputeGaussianTepalte(pTemXX,nR,fSigma,21);
	ComputeGaussianTepalte(pTemYY,nR,fSigma,22);
	for(int i=0; i < nN*nN; i++)
	{
		pTem_Log[i] = pTemXX[i] + pTemYY[i];
	}

	wzhConvol(pResult, pOri,nWidth,nHeight,pTem_Log,nR);
	wzhAbs(pResult,nWidth*nHeight);
	wzhFreePointer(pTemXX);
	wzhFreePointer(pTemYY);
	wzhFreePointer(pTem_Log);
}

void	wzhFreePointer(short* pP)
{
	if(pP != NULL)
	{
		delete pP;
		pP = NULL;
	}
}

void	wzhFreePointer(float* pP)
{
	if(pP != NULL)
	{
		delete pP;
		pP = NULL;
	}
}

void	wzhFreePointer(double* pP)
{
	if(pP != NULL)
	{
		delete pP;
		pP = NULL;
	}
}
void	wzhFreePointer(byte* pP)
{
	if(pP != NULL)
	{
		delete pP;
		pP = NULL;
	}
}
void	wzhFreePointer(int* pP)
{
	if(pP != NULL)
	{
		delete pP;
		pP = NULL;
	}
}

void	NormalizePs2D(double* pNewPs,double T[3][3],double* pPs,int nCount)
{		
	double* pTemp = new double[nCount*3];
	memcpy(pTemp,pPs,sizeof(double)*nCount*3);

	//��������
	double rrC = 0.0f;
	double ccC = 0.0f;
	for(int i = 0; i < nCount; i++)
	{
		rrC		= rrC + pPs[3*i];
		ccC		= ccC + pPs[3*i+1];
	}
	rrC = rrC / nCount;
	ccC = ccC / nCount;

	//��һ��������
	for(int i = 0; i < nCount; i++)
	{
		pTemp[3*i]		= pPs[3*i]		- rrC;
		pTemp[3*i+1]	= pPs[3*i+1]	- ccC;
	}

	//���㷽��
	double meandist = 0.0f;
	for(int i = 0; i < nCount; i++)
	{
		meandist = meandist + sqrt(pTemp[3*i] * pTemp[3*i] + pTemp[3*i+1] * pTemp[3*i+1]);
	}
	meandist = meandist/nCount;

	//����任
	double scale = (double)sqrt((double)2)/meandist;
	double T_t[3][3] = {	{scale,	0,		-scale*rrC},
						{0,		scale,	-scale*ccC},
						{0,		0,		1}};
	memcpy(&T[0][0],T_t,sizeof(double)*9);

	//����������	newpts = T*pts;
	for(int i = 0; i < nCount; i++)
	{
		pNewPs[3*i]		= T[0][0]*pPs[3*i] + T[0][1]*pPs[3*i+1] + T[0][2]*pPs[3*i+2];
		pNewPs[3*i+1]	= T[1][0]*pPs[3*i] + T[1][1]*pPs[3*i+1] + T[1][2]*pPs[3*i+2];
		pNewPs[3*i+2]	= T[2][0]*pPs[3*i] + T[2][1]*pPs[3*i+1] + T[2][2]*pPs[3*i+2];
	}

	//�ͷ��ڴ�
	wzhFreePointer(pTemp);
}

//*************************************************************************
//
//	�ú��� ͨ��ֱ�����Ա任���������
//	pP1 �������
//	pP2	�������
//
//*************************************************************************
void	ComputeFundamental(double F[3][3],double* pP1,double* pP2,int nCount)
{
	//ת��Ϊ�������
	double* pNewP1	= new double[nCount*3];
	double* pNewP2	= new double[nCount*3];

	//��һ��
	double T1[3][3] = {0};
	double T2[3][3] = {0};
	NormalizePs2D(pNewP1,T1,pP1,nCount);
	NormalizePs2D(pNewP2,T2,pP2,nCount);

	//�������
	double* AA = new double[nCount*9];
	for(int g = 0; g < nCount; g++)
	{

		AA[9*g+0] = pNewP2[3*g+0]*pNewP1[3*g+0];
		AA[9*g+1] = pNewP2[3*g+0]*pNewP1[3*g+1];
		AA[9*g+2] = pNewP2[3*g+0];

		AA[9*g+3] = pNewP2[3*g+1]*pNewP1[3*g+0];
		AA[9*g+4] = pNewP2[3*g+1]*pNewP1[3*g+1];
		AA[9*g+5] = pNewP2[3*g+1];

		AA[9*g+6] = pNewP1[3*g+0];
		AA[9*g+7] = pNewP1[3*g+1];
		AA[9*g+8] = 1.0f;
	} 

	//����ֵ�ֽ�
	initM(MATCOM_VERSION);
	Mm mMatrix = zeros(nCount,9);
	for(int g1 = 0; g1 < nCount; g1++)
		for(int g2 = 0; g2 < 9; g2++)
		{
			mMatrix.r(g1+1,g2+1) = AA[g1*9+g2];
		}

	//����ֵ�ֽ��þ�ȷλ��
	Mm u,s,v;
	i_o_t i_o = {0,0};
	svd(mMatrix,i_o,u,s,v);
	
	//ʹF������ʽΪ0
	Mm Fm = zeros(3,3);
	for(int i = 1; i < 4; i++)
		for(int j = 1; j < 4; j++)
		{
			int k = (i-1)*3 + j;
			Fm.r(i,j) = v.r(k,9);
		}
	svd(Fm,i_o,u,s,v);
	Mm mTemp = zeros(3,3);
	mTemp.r(1,1)  = s.r(1,1);
	mTemp.r(2,2)  = s.r(2,2);
	Fm = u*mTemp*ctranspose(v);

	//ת��Ϊ������ʽ
	double F_Temp[3][3] = {0};
	for(int i = 0; i < 3; i++)
		for(int j = 0; j < 3; j++)
		{
			int k = 3*i+j;
			F_Temp[i][j] = (double)Fm.r(i+1,j+1);
		}
		
	//�˳�
	exitM();

	//����任 T2'*F_temp*T1';
	double FF[3][3];
	for(int i = 0; i < 3; i++)
		for(int j = 0; j < 3; j++)
		{
			FF[i][j] =  T2[0][i]*F_Temp[0][j] + T2[1][i]*F_Temp[1][j] + T2[2][i]*F_Temp[2][j];
		}
	for(int i = 0; i < 3; i++)
		for(int j = 0; j < 3; j++)
		{
			F[i][j] =  FF[i][0]*T1[0][j] + FF[i][1]*T1[1][j] + FF[i][2]*T1[2][j];
		}
	
	//�ͷ��ڴ�
	wzhFreePointer(pNewP1);
	wzhFreePointer(pNewP2);
	wzhFreePointer(AA);
}

void GetSmallRegion(double* pSmallImage,double* m_pImage,int nWidth,int m_nHeight,int nCornerR,int nCornerC,int nRadius)
{
	int nCount = 0;
	for(int i = nCornerR-nRadius; i <= nCornerR+nRadius; i++)
		for(int j = nCornerC-nRadius; j <= nCornerC+nRadius; j++)
		{
			int k = i*nWidth + j;
			pSmallImage[nCount++] = m_pImage[k];
		}
}

/********************************************************************
Determine if point ('x', 'y') is within a circle of 'radius', 
assuming the circle center is (0, 0).
********************************************************************/
bool IsInCircle(double x, double y, double radius)
{
	if ((x * x + y * y) <= (radius * radius))
	{
		return true;
	}
	else
	{
		return false;
	}
}

/********************************************************************
Fit a parabola to the three points (-1.0; left), (0.0; middle) 
and (1.0; right).
Formula : f(x) = a (x - c)^2 + b.
where c is the peak offset, b is the peak value.
If the parabola interpolating is successed, return true, 
otherwise return false.
********************************************************************/
bool ParabolaInter(double &peakPos, double &peakVal, double left, double middle, double right)
{
	double a = ((left + right) - 2.0f * middle) / 2.0f;

	// not a parabola, a horizontal line.
	if (a == 0.0)
	{
		return false;
	}

	double c = (((left - middle) / a) - 1.0f) / 2.0f;
	double b = middle - c * c * a;

	// 'middle' is not a peak.
	if (c < -0.5 || c > 0.5)
	{
		return false;
	}

	peakPos = c;
	peakVal = b;

	return true;
}

void	FFT1(double pResult[],double* pData, int nN)
{
	double r0 = 0;
	double i0 = 0;
	double r1 = 0;
	double i1 = 0;
	double r2 = 0;
	double i2 = 0;
	double r3 = 0;
	double i3 = 0;
	for(int i = 0; i < nN; i++)
	{
		r0 = r0 + pData[i]*cos(2*PI*0*i/nN);
		i0 = i0 + pData[i]*sin(2*PI*0*i/nN);
		r1 = r1 + pData[i]*cos(2*PI*1*i/nN);
		i1 = i1 + pData[i]*sin(2*PI*1*i/nN);
		r2 = r2 + pData[i]*cos(2*PI*2*i/nN);
		i2 = i2 + pData[i]*sin(2*PI*2*i/nN);
		r3 = r3 + pData[i]*cos(2*PI*3*i/nN);
		i3 = i3 + pData[i]*sin(2*PI*3*i/nN);
	}

	pResult[0] = sqrt(r0*r0 + i0*i0);
	pResult[1] = sqrt(r1*r1 + i1*i1);
	pResult[2] = sqrt(r2*r2 + i2*i2);
	pResult[3] = sqrt(r3*r3 + i3*i3);
}

void	ComputerJu(double pResult[],double* pData, int nN)
{
	//�����ֵ
	double dAvg = 0;
	for(int i = 0; i < nN; i++)
	{
		dAvg = dAvg + pData[i];
	}
	dAvg = dAvg/nN;

	//�����
	double Ju1 = 0;
	double Ju2 = 0;
	double Ju3 = 0;
	for(int i = 0; i < nN; i++)
	{
		double error = abs(pData[i]-dAvg);
		Ju1 = Ju1 + error;
		Ju2 = Ju2 + error*error;
		Ju3 = Ju3 + error*error*error;
	}

	pResult[0] = dAvg;
	pResult[1] = (Ju1/nN);
	pResult[2] = (Ju2/nN);
	pResult[3] = (Ju3/nN);
}

void	ComputeAvgAndStd(double& dAvg,double& dStd,double* pData,int nN)
{
	//�����ֵ
	dAvg = 0;
	for(int i = 0; i < nN; i++)
	{
		dAvg = dAvg + pData[i];
	}
	dAvg = dAvg/nN; 

	//�����׼�� 
	dStd = 0;
	for(int i = 0; i < nN; i++)
	{
		double error = (pData[i]-dAvg);
		dStd = dStd + error*error;
	}
	dStd = sqrt(dStd/nN);
}

double  LimitArc(double dArc)
{
	if(dArc < 0)
		dArc = dArc + 2*PI;
	else if(dArc > 2*PI)
		dArc = dArc - 2*PI;

	return dArc;
}

double	ArcDis(double dArc1,double dArc2)
{
	double error = abs(dArc1-dArc2);
	if(error > PI)
		error = 2*PI - error;

	return error;
}