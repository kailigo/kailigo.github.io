Input: FirstImage SecondImage LineSegment1 LineSegment2
Output: LineSegmentMatches (File name: LineMatches.txt)
The file "run.bat" provides an example of using this software.

The implementation is based on OpenCV 2.4.3. Therefore, you need *.dll files provided by this OpenCV version to run the software.